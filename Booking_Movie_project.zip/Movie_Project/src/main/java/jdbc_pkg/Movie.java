package jdbc_pkg;
public class Movie {
    private int movieId;
    private String title;
    private String genre;
    private String language;
    private int duration;
    private double rating;
    private String city;
    private String description;
    private byte[] poster;
    private int total_seats;
    private int booked_seats;

    // Getters and setters...
    // Default constructor
    public Movie() {
    }

    // Parameterized constructor
    public Movie(int movieId, String title, String genre, String language, int duration, double rating, String city, String description, byte[] poster, int total_seats, int booked_seats) {
        this.movieId = movieId;
        this.title = title;
        this.genre = genre;
        this.language = language;
        this.duration = duration;
        this.rating = rating;
        this.city = city;
        this.description = description;
        this.poster = poster;
        this.total_seats = total_seats;  
        this.booked_seats = booked_seats;
    }

    // Getters and Setters

	public String getCity() {
	    return city;
	}
	
	public void setCity(String city) {
	    this.city = city;
	}
    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public int getTotalSeats() {
        return total_seats;
    }

    public void setTotalSeats(int total_seats) {
        this.total_seats = total_seats;
    }
    public int getBookedSeats() {
        return booked_seats;
    }

    public void setBookedSeats(int booked_seats) {
        this.booked_seats = booked_seats;
    }
    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public byte[] getPoster() {
        return poster;
    }
    public void setPoster(byte[] poster) {
        this.poster = poster;
    }

}