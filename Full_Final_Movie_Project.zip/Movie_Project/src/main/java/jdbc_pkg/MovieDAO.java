package jdbc_pkg;

import java.sql.*;
import java.util.*;

public class MovieDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/movie";
    private String jdbcUsername = "root";
    private String jdbcPassword = "riya";
    
    public MovieDAO(){
    	try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public List<Movie> getAllMovies() {
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT * FROM movies";

        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Movie movie = new Movie();
                movie.setMovieId(rs.getInt("movie_id"));
                movie.setTitle(rs.getString("title"));
                movie.setGenre(rs.getString("genre"));
                movie.setLanguage(rs.getString("language"));
                movie.setDuration(rs.getInt("duration"));
                movie.setRating(rs.getDouble("rating"));
                movie.setCity(rs.getString("city"));
                movie.setDescription(rs.getString("description"));
                byte[] posterBytes = rs.getBytes("poster");
                movie.setPoster(posterBytes);
                movie.setTotalSeats(rs.getInt("total_seats"));
                movie.setBookedSeats(rs.getString("booked_seats"));
                movies.add(movie);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return movies;
    }
    
    public List<Movie> getMoviesByCity(String city) {
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT * FROM movies WHERE city = ?";

        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, city);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Movie movie = new Movie();
                movie.setMovieId(rs.getInt("movie_id"));
                movie.setTitle(rs.getString("title"));
                movie.setGenre(rs.getString("genre"));
                movie.setLanguage(rs.getString("language"));
                movie.setDuration(rs.getInt("duration"));
                movie.setRating(rs.getDouble("rating"));
                movie.setCity(rs.getString("city"));
                movie.setDescription(rs.getString("description"));
                byte[] posterBytes = rs.getBytes("poster");
                movie.setPoster(posterBytes);
                movie.setTotalSeats(rs.getInt("total_seats"));
                movie.setBookedSeats(rs.getString("booked_seats"));
                movies.add(movie);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return movies;
    }
    
    public List<Movie> getFilteredMovies(String city, String genre, String language, String search) {
        List<Movie> movies = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM movies WHERE 1=1");

        if (city != null) {
            sql.append(" AND city = ?");
        }
        if (genre != null) {
            sql.append(" AND genre = ?");
        }
        if (language != null) {
            sql.append(" AND language = ?");
        }
        if (search != null) {
            sql.append(" AND title LIKE ?");
        }

        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            int index = 1;
            if (city != null) stmt.setString(index++, city);
            if (genre != null) stmt.setString(index++, genre);
            if (language != null) stmt.setString(index++, language);
            if (search != null) stmt.setString(index++, "%" + search + "%");  // Wildcard match

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Movie movie = new Movie();
                movie.setMovieId(rs.getInt("movie_id"));
                movie.setTitle(rs.getString("title"));
                movie.setGenre(rs.getString("genre"));
                movie.setLanguage(rs.getString("language"));
                movie.setDuration(rs.getInt("duration"));
                movie.setRating(rs.getDouble("rating"));
                movie.setCity(rs.getString("city"));
                movie.setDescription(rs.getString("description"));
                byte[] posterBytes = rs.getBytes("poster");
                movie.setPoster(posterBytes);
                movie.setTotalSeats(rs.getInt("total_seats"));
                movie.setBookedSeats(rs.getString("booked_seats"));
                movies.add(movie);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return movies;
    }
    
    public Movie getMovieById(int id) {
        String sql = "SELECT * FROM movies WHERE movie_id = ?";
        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Movie movie = new Movie();
                movie.setMovieId(rs.getInt("movie_id"));
                movie.setTitle(rs.getString("title"));
                movie.setGenre(rs.getString("genre"));
                movie.setLanguage(rs.getString("language"));
                movie.setDuration(rs.getInt("duration"));
                movie.setRating(rs.getDouble("rating"));
                movie.setCity(rs.getString("city"));
                movie.setDescription(rs.getString("description"));
                byte[] posterBytes = rs.getBytes("poster");
                movie.setPoster(posterBytes);
                movie.setTotalSeats(rs.getInt("total_seats"));
                movie.setBookedSeats(rs.getString("booked_seats"));
                return movie;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }




}
