package movie_pkg;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jdbc_pkg.Movie;
import jdbc_pkg.MovieDAO;

public class BookingServlet extends HttpServlet {
    private MovieDAO movieDAO = new MovieDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String idParam = request.getParameter("id");
        if (idParam != null) {
            int id = Integer.parseInt(idParam);
            Movie movie = movieDAO.getMovieById(id);  // fetch movie from DB
            request.setAttribute("movie", movie);
        }
        
        // forward to JSP
        request.getRequestDispatcher("/booking.jsp").forward(request, response);
    }
}

