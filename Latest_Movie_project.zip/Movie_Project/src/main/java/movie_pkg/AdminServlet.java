package movie_pkg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jdbc_pkg.*;

public class AdminServlet extends HttpServlet {
	
	//private static final long serialVersionUID = 1L;
		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			PrintWriter out = resp.getWriter();
			String action = req.getParameter("action");
	        if(action != null) {
	            String name = req.getParameter("name");
	            String genre = req.getParameter("genre");
	            String duration = req.getParameter("duration");
	            String language = req.getParameter("language");
	            String city = req.getParameter("city");
	            String description = req.getParameter("description");
	            String rating = req.getParameter("rating");

	            try {
	                Class.forName("com.mysql.cj.jdbc.Driver");
	                Connection con = DriverManager.getConnection(
	                    "jdbc:mysql://localhost:3306/movie","root","riya");

	                if(action.equals("add")) {
	                    PreparedStatement ps = con.prepareStatement(
	                        "INSERT INTO movies(title, genre, duration, language, city, description, rating) VALUES(?,?,?,?,?,?,?)");
	                    ps.setString(1, name);
	                    ps.setString(2, genre);
	                    ps.setString(3, duration);
	                    ps.setString(4, language);
	                    ps.setString(5, city);
	                    ps.setString(6, description);
	                    ps.setString(7, rating);
	                    ps.executeUpdate();
	                    req.setAttribute("message", "addSuccess");
	                    req.getRequestDispatcher("admin.jsp").forward(req, resp);
	                    resp.sendRedirect("admin.jsp");
	                } else if(action.equals("delete")) {
	                    PreparedStatement ps = con.prepareStatement(
	                        "DELETE FROM movies WHERE title=?");
	                    ps.setString(1, name);
	                    int rows = ps.executeUpdate();
	                    if(rows > 0) {
	                    	req.setAttribute("message", "deleteSuccess");
	                    	req.getRequestDispatcher("admin.jsp").forward(req, resp);
	                        resp.sendRedirect("admin.jsp");
	                    } else {
	                        out.println("<p style='color:orange;'>Movie not found!</p>");
	                    }
	                }

	                con.close();
	            } catch(Exception e) {
	                out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
	            }
	        }
		}
	}