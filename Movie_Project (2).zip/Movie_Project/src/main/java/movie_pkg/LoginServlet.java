package movie_pkg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jdbc_pkg.*;

public class LoginServlet extends HttpServlet {
	
	//private static final long serialVersionUID = 1L;
		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			PrintWriter out = resp.getWriter();
			String user = req.getParameter("user");
			String pass = req.getParameter("password");
			
			User_module um = new User_module();
			boolean isAuth = um.logUser(user,pass);
			if(isAuth) {
				resp.sendRedirect("main"); 
			}
			else {
				out.println("<h2>Invalid Credentials</h2>");
			}
			
		}
	}