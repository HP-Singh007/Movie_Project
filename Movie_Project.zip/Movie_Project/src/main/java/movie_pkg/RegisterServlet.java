package movie_pkg;

import jdbc_pkg.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class RegisterServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String user = req.getParameter("user");
		String pass = req.getParameter("password");
		String email = req.getParameter("email");
		String phone = req.getParameter("phone");
		
		PrintWriter out = resp.getWriter();
		
		User_module um = new User_module();
		boolean isAuth = um.regUser(user, pass, email, phone);
		if(isAuth) {
			HttpSession session = req.getSession();
			session.setAttribute("isAuthenticated", true);
			session.setAttribute("username", user); 
			resp.sendRedirect("main"); 
		}
		else {
			out.println("<h2>Something Went Wrong</h2>");
		}		
	}


}
