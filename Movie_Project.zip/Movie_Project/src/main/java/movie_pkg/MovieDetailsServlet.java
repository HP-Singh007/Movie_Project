package movie_pkg;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

import jdbc_pkg.Movie;
import jdbc_pkg.MovieDAO;

public class MovieDetailsServlet extends HttpServlet {
    private MovieDAO movieDAO;

    public void init() {
        movieDAO = new MovieDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idParam = request.getParameter("id");

        if (idParam != null && !idParam.trim().isEmpty()) {
            int movieId = Integer.parseInt(idParam.trim());
            Movie movie = movieDAO.getMovieById(movieId);

            if (movie != null) {
                request.setAttribute("movie", movie);
                request.getRequestDispatcher("movie_details.jsp").forward(request, response);
                return;
            }
        }

        // Redirect or show error if movie not found
        response.sendRedirect("main");
    }
}
